import rclpy
from rclpy.node import Node
from std_msgs.msg import String

from pynput import keyboard
import getpass
import pygame
import pygame_gui
from pygame.locals import *
import time
class KeyboardController(Node):
    
     def listener_callback(self, msg):
          msg = String()
          RED = (255, 0, 0)
          pygame.init()
          pygame.display.set_caption('Robot GUI')
          window_surface = pygame.display.set_mode((800,600))
          background = pygame.Surface((800, 600))
          background.fill(pygame.Color('#000000'))
          manager = pygame_gui.UIManager((800, 600))
          movef_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((125,0), (115, 50)),text='Move Forward',manager=manager)
          moveb_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((125,150), (115, 50)),text='Move Backward',manager=manager)
          turnr_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((0,75), (115, 50)),text='Turn Left',manager=manager)
          turnl_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((230,75), (115, 50)),text='Turn Right',manager=manager)
          ultraf_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((430,0), (250, 50)),text='Ultrasonic Front Sensor',manager=manager)
          ultrar_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((430,75), (250, 50)),text='Ultrasonic Right Sensor',manager=manager)
          ultral_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((430,150), (250, 50)),text='Ultrasonic Left Sensor',manager=manager)
          auto_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((0,250), (250, 50)),text='Fully Automatic',manager=manager)
          autof_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((300,250), (250, 50)),text='Forward Speed Automatic',manager=manager)
          autob_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((600,250), (200, 50)),text='Backward Speed Automatic',manager=manager)
          stop_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((0,500), (115,50)),text='Stop',manager=manager)
          constf_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((0,350), (200, 50)),text='Constant Forward',manager=manager)
          constb_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((0,425), (200, 50)),text='Constant Backward',manager=manager)
          editf_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((250,350), (200, 50)),text='Edit Forward',manager=manager)
          editb_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((250,425), (200, 50)),text='Edit Backward',manager=manager)
          quit_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((250,500), (200,50)),text='Quit',manager=manager)
          clock = pygame.time.Clock()
          is_running = True
 
          while is_running:
              time_delta = clock.tick(60)/1000.0
              for event in pygame.event.get():
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == quit_button:
                              is_running = False
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == movef_button:
                              msg.data = "MOVEF:1000"
                              self.publisher.publish(msg)
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == moveb_button:
                              msg.data = "MOVEB:1000"
                              self.publisher.publish(msg)
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == turnr_button:
                              msg.data = "TURNL:0100"
                              self.publisher.publish(msg)
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == turnl_button:
                              msg.data = "TURNR:0100"
                              self.publisher.publish(msg)
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == stop_button:
                              msg.data = "STOPR:0000"
                              self.publisher.publish(msg)
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == constf_button:
                              msg.data = "CONTF:00100"
                              self.publisher.publish(msg)
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == constb_button:
                              msg.data = "CONTB:00100"
                              self.publisher.publish(msg)
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == editf_button:
                              print("EDIT_SPEED_FORWARD_10")
                              speed = input("Please enter the speed: ")
                              msg.data = "CONTF:%s" %speed
                              self.publisher.publish(msg)
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == editb_button:
                              print("EDIT_SPEED_BACKWARD_10")
                              speed = input("Please enter the speed: ")
                              msg.data = "CONTF:%s" %speed
                              self.publisher.publish(msg)
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == ultraf_button:
                              print("85")
                              time.sleep(1)
                              print("84")
                              time.sleep(1)
                              print("80")
                              time.sleep(1)
                              print("45")
                              time.sleep(1)
                              print("40")
                              time.sleep(1)
                              print("15")
                              time.sleep(1)
                              print("15")
                              time.sleep(1)
                              print("15")
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == ultral_button:
                              print("1084")
                              time.sleep(1)
                              print("1084")
                              time.sleep(1)
                              print("185")
                              time.sleep(1)
                              print("1084")
                              time.sleep(1)
                              print("85")
                              time.sleep(1)
                              print("45")
                              time.sleep(1)
                              print("90")
                              time.sleep(1)
                              print("1084")
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == ultrar_button:
                              print("1084")
                              time.sleep(1)
                              print("10")
                              time.sleep(1)
                              print("184")
                              time.sleep(1)
                              print("80")
                              time.sleep(1)
                              print("85")
                              time.sleep(1)
                              print("45")
                              time.sleep(1)
                              print("90")
                              time.sleep(1)
                              print("1084")
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == auto_button:
                                msg.data = "CONTF:0100"
                                self.publisher.publish(msg)
                                msg.data = "CONTB:0100"
                                self.publisher.publish(msg)
                                msg.data = "TURNL:0100"
                                self.publisher.publish(msg)
                                msg.data = "TURNR:0100"
                                self.publisher.publish(msg)
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == autof_button:
                                msg.data = "CONTF:0100"
                                self.publisher.publish(msg)
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == autob_button:
                                msg.data = "CONTB:0100"
                                self.publisher.publish(msg)
                  manager.process_events(event)
                  
              manager.update(time_delta)
              window_surface.blit(background, (0, 0))
              manager.draw_ui(window_surface)
              pygame.display.update()

     def __init__(self):
          super().__init__('KeyboardController')
          self.publisher = self.create_publisher(String, '/robot/control', 10)
          self.subscription = self.create_subscription(
            String,
            '/robot/right',
          self.listener_callback,
            10)
          self.subscription = self.create_subscription(
            String,
            '/robot/left',
          self.listener_callback,
            10)
          self.subscription = self.create_subscription(
            String,
            '/robot/front',
          self.listener_callback,
            10)
          self.subscription  # prevent unused variable warning
       
         
def main(args=None):
    rclpy.init(args=args)

    controller = KeyboardController()
    rclpy.spin(controller)

    controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
